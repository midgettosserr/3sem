var searchData=
[
  ['addschool_14',['addSchool',['../classTable.html#a1fe9e86ef87323c7e266ed89e19ea234',1,'Table']]],
  ['addskill_15',['addSkill',['../classTable.html#a762abb789633d20d999e8acf1e933f40',1,'Table']]]
];
