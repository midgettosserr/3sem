var searchData=
[
  ['getcreature_4',['getCreature',['../classTable.html#ab412b33bd1afaf37f16a5f5cd03c707d',1,'Table']]],
  ['getschool_5',['getSchool',['../classTable.html#a261cad9a7025da87da29f9b031943e78',1,'Table']]],
  ['getskill_6',['getSkill',['../classTable.html#a9517c409f4bb485cd7285eeb7da15352',1,'Table']]]
];
